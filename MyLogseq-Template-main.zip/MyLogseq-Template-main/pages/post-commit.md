#!/bin/sh

git push origin main
