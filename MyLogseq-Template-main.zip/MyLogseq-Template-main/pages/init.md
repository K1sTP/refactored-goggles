git init
git remote add origin https://github.com/fishyer/MyLogseq-Template.git
git checkout -b main
git add .
git commit -m "init"
git push -f origin main
